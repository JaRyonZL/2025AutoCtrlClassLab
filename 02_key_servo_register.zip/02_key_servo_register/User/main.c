/*
 * @Descripttion: 主函数
 * @Author: JaRyon
 * @version: 
 * @Date: 2025-09-11 10:21:11
 */
// FileName: main.c

#include "includes.h"

int main(void)
{
	// key TIM2 Servo Init ---------------------------------------------------
	SERVO_Init();
	KEY_Init();

	// while loop --------------------------------------------------------
	while(1)
	{

	}
}




