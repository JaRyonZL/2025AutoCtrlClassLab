/*
 * @Descripttion: 
 * @Author: JaRyon
 * @version: 
 * @Date: 2025-09-11 10:53:51
 */
// FileName: includes.h 

#ifndef __INCLUDES_H
#define __INCLUDES_H

#include "stm32f10x.h"
#include "Delay.h"
#include "tim2.h"
#include "servo.h"
#include "key.h"

#endif // !__INCLUDES_H
