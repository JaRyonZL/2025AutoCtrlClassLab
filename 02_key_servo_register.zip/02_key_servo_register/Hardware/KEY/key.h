#ifndef __KEY_H
#define __KEY_H

// 舵机角度定义
#define ANGLE_0     0
#define ANGLE_90    90
#define ANGLE_180   180

void KEY_Init(void);

#endif
